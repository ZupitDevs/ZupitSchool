Somebody else wrote this
